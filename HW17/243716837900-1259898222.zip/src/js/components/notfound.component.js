export class NotFoundComponent {
    render() {
        return `
            <div>404</div>
        `;
    }
    
    afterRender() {}
}

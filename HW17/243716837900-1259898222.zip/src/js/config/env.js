export const ENV = {
    mode: 'dev',
    apiUrl: 'https://mostlikedperson-api.herokuapp.com/api'
}

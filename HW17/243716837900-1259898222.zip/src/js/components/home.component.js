export class HomeComponent {
    constructor() {
        
    }
    render() {
        return `
            <div>Home</div>
        `;
    }

    afterRender() {}
}
